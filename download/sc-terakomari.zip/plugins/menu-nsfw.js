let handler = async (m) => {
  m.reply(`
╭─────『 Menu NSFW 』
Otak Bokep
╰–––––––––––––––༓
  `.trim())
}
handler.command = /^menunsfw$/i
handler.help = ["menunsfw"]
handler.tags = ["main"]
export default handler